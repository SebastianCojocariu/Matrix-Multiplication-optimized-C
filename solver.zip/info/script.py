import matplotlib.pyplot as plt
import matplotlib
import numpy as np


def function_plot(filename):
	MAX = 1600
	x = range(80,MAX + 1,80)
	y = []	
	with open(filename) as f:
		content = f.readlines()
		for line in content:
			y.append(float((line.split("\n")[0]).split("=")[1]));
	#plt.plot(x,y,'ro')
	#plt.axis([0,MAX + MAX*0.1,0,35])
	#plt.ylabel(filename)
	#plt.show()

	fig = plt.figure()
	ax = plt.subplot()
	ax.plot(x, y, label='$y = numbers')
	#plt.title('Legend inside')
	ax.legend()
	#plt.show()
	 
	fig.savefig(filename + ".png")

def function_compare(list):
	color = ["red","green","blue","orange"]
	j = 0
	fig = plt.figure()
	maxim = -1	
	for file in list:
		MAX = 1600
		x = range(80,MAX + 1,80)
		y = []	
		with open(file) as f:
			content = f.readlines()
			for line in content:
				y.append(float((line.split("\n")[0]).split("=")[1]));
		
		ax = plt.subplot()
		ax.scatter(x, y, label=file.split("_",2)[2],color = color[j])
		
		j = j + 1
		if maxim < y[19]:
			maxim = y[19]
		#plt.title('Legend inside')
		ax.legend(loc='upper center', bbox_to_anchor=(0.5, 1.00), shadow=True, ncol=2)

	plt.axis([0,1800,0,maxim + maxim*0.15])
	fig.savefig(list[0].split("_")[0] + "_comparison.png")

def function_gcc_icc_comp(gcc_list,icc_list):
	for i in range(0,4):
		fig = plt.figure()

		plt.title('gcc_icc_' + gcc_list[i].split("_",2)[2])
		list = [gcc_list[i],icc_list[i]]

		list_type = ["gcc","icc"]
		color = ["red","blue"]
		print list[0],list[1]
		j = 0
		maxim = -1
		for file in list:
			MAX = 1600
			x = range(80,MAX + 1,80)
			y = []	
			with open(file) as f:
				content = f.readlines()
				for line in content:
					y.append(float((line.split("\n")[0]).split("=")[1]));
			
			#ax = plt.subplot()
			
			plt.scatter(x, y,label = list_type[j], color = color[j])
			j = j+1
			plt.legend(loc='upper center', bbox_to_anchor=(0.5, 1.00), shadow=True, ncol=2)
			if maxim < y[19]:
				maxim = y[19]
			#plt.title('Legend inside')
		plt.axis([0,1800,0,maxim + maxim*0.15])
		fig.savefig("comparison_tema2_" + list[0].split("_",2)[2] + ".png")


gcc_list = ["gcc_tema2_neopt","gcc_tema2_opt_f","gcc_tema2_opt_m","gcc_tema2_blas"]
icc_list = ["icc_tema2_neopt","icc_tema2_opt_f","icc_tema2_opt_m","icc_tema2_blas"]

function_gcc_icc_comp(gcc_list,icc_list)
function_compare(gcc_list)
function_compare(icc_list)	
#	for file in gcc_list:
#		function_plot(file)
#	for file in icc_list:
#		function_plot(file)
