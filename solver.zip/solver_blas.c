/*
 * Tema 2 ASC
 * 2019 Spring
 * Catalin Olaru / Vlad Spoiala
 */
#include "utils.h"
#include "cblas.h"
/* 
 * Add your BLAS implementation here
 */
double* my_solver(int N, double *A, double *B) {
	double *X = (double*)calloc(N*N,sizeof(double)); 
	cblas_dsyr2k(CblasRowMajor, CblasUpper,
                  CblasTrans, N, N,
                  1, A, N,
                  B, N, 0,
                  X, N);
	double *res = (double*)calloc(N*N,sizeof(double)); 
	cblas_dgemm(CblasRowMajor, CblasNoTrans,
                 CblasNoTrans, N, N,
                 N, 1, X,
                 N, X, N,
                 0, res, N);
	return res;
}
