/*
 * Tema 2 ASC
 * 2019 Spring
 * Catalin Olaru / Vlad Spoiala
 */
#include "utils.h"
#include "stdio.h"
#include "string.h"

/*
 * Add your optimized implementation here
 */

double *transpose(int N, double *A){

	double *res = (double*)malloc(N * N * sizeof(double));

	//daca nu am putut aloca
	if (res == NULL)
		return NULL;

	register double *aux_ptr;
	
	for(int i = 0; i < N; i++){
		aux_ptr = res + i;
		for(int j = 0; j < N; j++){
			*aux_ptr = *A;
			A++;
			if(j < N-1)
				aux_ptr = aux_ptr + N;
		}
	}

	return res;
}

void addition(int N, double *A, double *B,double *res){
	int i, j;
	register double *pa;
	register double *pb;
	register double *aux_ptr;
	for(i = 0; i < N; i++){
		pa = A + i*N;
    		pb = B + i*N;
		aux_ptr = res + i*N;
		for(j = 0; j < N; j++){
			*aux_ptr = *pa + *pb;
			aux_ptr++;
			pa++;
			pb++;
		}
	}
}

void transfer_back(int N,int length,double *A,double *res){
	register double *aux_ptr;
	for(int i = 0;i < length; i++){
		aux_ptr = res + i*N;
		for(int j = 0;j < length; j++){
			*aux_ptr = *A;
			aux_ptr++;
			A++;
		}
	}
}

// implementarea cu inmultirea pe blocuri. (e totusi mai ineficienta)
/*void my_multiply(int N,int length,double *A,double *B,double *res){
	register double *pa;
	register double *pb;
	register double suma = 0;
	register double *orig_pa;
	for(int i = 0; i < length; i++){
  		orig_pa = A + i * N;
  		for(int j = 0; j < length; j++){
	    	    pa = orig_pa;
		    pb = B + j;
		    suma = 0;
		    for(int k = 0; k < length; k++){
		      suma += *pa * *pb;
		      pa++;
		      pb += N;
		    }
		    *res = suma;
		    res++;
	  }
	}

}

//functie care face zero
double *multiply(int N, double *A, double *B){
	register double *res = (double*)calloc(N * N ,sizeof(double));
	register double *ptr_res;
	register double *ptr_A;
	register double *ptr_B;
	int no = 40;

	//daca nu am putut aloca
	if (res == NULL)
		return NULL;

	int size = N/no;
	
	register double *sum = (double*)calloc(no*no,sizeof(double));
	register double *product = (double*)calloc(no*no,sizeof(double));

	for(int i = 0;i<size;i++){
		for(int j = i;j<size;j++){
			int line = i*no;
			int column = j*no;
			ptr_res = res + line*N+column;
			ptr_A = A + line*N;
			ptr_B = B + column;
			memset(sum, 0, no * no * sizeof(double));
			memset(product, 0, no * no * sizeof(double));

			for(int k = 0;k < size;k++){
				int length = no;
				my_multiply(N, length, ptr_A, ptr_B, product);
				addition(length, sum, product, sum);

				if(k < size-1){
					ptr_A = ptr_A + length;
					ptr_B = ptr_B + length*N;
				}
			}
			transfer_back(N,no,sum,ptr_res);	
		}
	}

	free(product);
	free(sum);

	//aplicam zerotr pe rezultat
	res = zerotr(N,res);
	
	return res;
}*/


double *zerotr(int N, double *A){
	register double *res = (double*)calloc(N * N , sizeof(double));
	register double *aux_ptr;
	register double *ptr_A;
	//daca nu am putut aloca
	if (res == NULL)
		return NULL;

	for(int i = 0; i < N; i++){
		aux_ptr = res +i * N + i;
		ptr_A = A + i * N +i;
		for(int j = i; j < N; j++){
			*aux_ptr = *ptr_A;
			if(j < N-1){
				aux_ptr++;
				ptr_A++;
			}
		}
	}
	return res;
}





double *multiply_fast(int N,double *A,double *B,int type){
	register double *res = (double*)calloc(N * N ,sizeof(double));
	register double *transpose_B = transpose(N,B);
	register double *aux_ptr = res;
	register double suma = 0;
	register double *ptr_A;
	register double *ptr_B;

	if(type == 0){
		for(int i = 0;i < N; i++){
			for(int j = 0; j < N; j++){
				ptr_A = A + i*N;
				ptr_B = transpose_B +j*N;
				suma = 0;
				for(int k = 0;k < N; k++){
					suma += *ptr_A * *ptr_B;
					ptr_A++;
					ptr_B++; 
				}
				*aux_ptr = suma;
				aux_ptr++;
			}	
		}
	}
	else if(type == 1){
		for(int i = 0; i < N; i++){
			for(int j = i; j < N; j++){
				ptr_A = A + i*N + i;
				ptr_B = transpose_B + j*N + i;
				suma = 0;
				for(int k = i;k <= j; k++){
					suma += *ptr_A * *ptr_B;
					ptr_A++;
					ptr_B++; 
				}
				aux_ptr[i * N + j] = suma;
			}	
		}
	}

	return res;	
}


double *getLower(int N,double *A){
	register double *res = (double*)calloc(N * N ,sizeof(double));
	register double *aux_ptr;
	register double *aux_A;
	
	for(int i = 0; i < N; i++){
		aux_ptr = res + i * N + i;
		aux_A = A + i * N + i;
		for(int j = i; j < N;j++){
			*aux_ptr = *aux_A;
			aux_ptr++;
			aux_A += N;
		}
	}

	return res; 
}


double* my_solver(int N, double *A, double* B) {
				//cazul pe blocuri 
	/*double *transp_A = transpose(N, A);
	double *transp_B = transpose(N, B);
	double *first_term = multiply(N, transp_A, B);
	double *second_term = multiply(N, transp_B, A);
	double *res;

	double *X = (double*)calloc(N*N,sizeof(double)); 
	addition(N, first_term, second_term,X);

	res = multiply(N, X, X);
	
	free(transp_A);
	free(transp_B);
	free(first_term);
	free(second_term);
	free(X);
	*/
				//cazul pe optimizare

	double *transp_A = transpose(N, A);
	double *first_term = multiply_fast(N, transp_A, B,0);
	double *second_term = getLower(N,first_term);
	first_term = zerotr(N,first_term);

	double *X = (double*)calloc(N*N,sizeof(double)); 
	addition(N, first_term, second_term,X);

	double *res = multiply_fast(N, X, X,1);

	free(transp_A);
	free(first_term);
	free(second_term);
	free(X);

	return res;	
}
