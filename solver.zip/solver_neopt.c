/*
 * Tema 2 ASC
 * 2019 Spring
 * Catalin Olaru / Vlad Spoiala
 */
#include "utils.h"

/*
 * Add your unoptimized implementation here
 */

double *transpose(int N, double *A){

	double *res = (double*)malloc(N * N * sizeof(double));

	//daca nu am putut aloca
	if (res == NULL)
		return NULL;
	
	for(int i = 0; i<N; i++)
		for(int j = 0; j<N; j++)
			res[j * N + i] = A[i * N + j];

	return res;
}

double *multiply(int N, double *A, double *B){
	double *res = (double*)malloc(N * N * sizeof(double));

	//daca nu am putut aloca
	if (res == NULL)
		return NULL;

	for(int i = 0; i < N; i++){
		for(int j = 0; j < N; j++){
			for(int k = 0; k < N; k++)
				res[i * N + j] +=  A[i * N + k] * B[k * N + j];
		}
	}
	
	return res;
}

double *addition(int N, double *A, double *B){
	double *res = (double*)malloc(N * N * sizeof(double));

	//daca nu am putut aloca
	if (res == NULL)
		return NULL;

	int i, j;
	for(i = 0; i < N; i++){
		for(j = 0; j < N; j++){
			res[i * N + j] = A[i * N + j] + B[i * N + j];
		}
	}
	return res;
}

double *zerotr(int N, double *A){
	double *res = (double*)malloc(N * N * sizeof(double));

	//daca nu am putut aloca
	if (res == NULL)
		return NULL;

	int i, j;
	for(i = 0; i < N; i++){
		for(j = 0; j < N; j++){
			if(j < i)
				res[i * N + j] = 0;
			else
				res[i * N + j] = A[i * N + j];
		}
	}
	return res;
}


double* my_solver(int N, double *A, double* B) {
	//printf("NEOPT SOLVER\n");

	double *transp_A = transpose(N, A);
	double *transp_B = transpose(N, B);
	double *first_term = multiply(N, transp_A, B); 
	double *second_term = multiply(N, transp_B, A); 
	double *X = addition(N, first_term, second_term);
	double *zero_tr = zerotr(N,X);
	double *res = multiply(N, zero_tr,zero_tr);
	
	free(transp_A);
	free(transp_B);
	free(first_term);
	free(second_term);
	free(zero_tr);
	free(X);
	return res;

}

