make -f Makefile
./tema2_neopt my_input > info/gcc_tema2_neopt
./tema2_opt_f my_input > info/gcc_tema2_opt_f
./tema2_opt_m my_input > info/gcc_tema2_opt_m
./tema2_blas my_input > info/gcc_tema2_blas

make clean

make -f Makefile.icc
./tema2_neopt my_input > info/icc_tema2_neopt
./tema2_opt_f my_input > info/icc_tema2_opt_f
./tema2_opt_m my_input > info/icc_tema2_opt_m
./tema2_blas my_input > info/icc_tema2_blas

make clean

rm out_* 
